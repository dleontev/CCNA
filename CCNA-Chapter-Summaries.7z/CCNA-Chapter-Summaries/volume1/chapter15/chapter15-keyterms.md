# Chapter 15 Key Terms

*   **broadcast subnet:** The last subnet in a classful network range. It has all host bits set to 1 in its subnet ID. The broadcast subnet's address is the same as the classful broadcast address.
*   **subnet zero:** The first subnet in a classful network range. It has all subnet bits set to 0 in its subnet ID. The subnet zero address is the same as the classful network address.
*   **zero subnet:**  Another term for subnet zero.